
import './App.css';

import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import Profile4 from './Profile4';


function App() {
  return (
   
 //<Signup/>

   <Router>
   <Switch>

            <Route exact path="/profile4"  component={Profile4} />
      
      </Switch>
    </Router>

  );
}

export default App;
