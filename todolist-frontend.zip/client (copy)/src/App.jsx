import React, { useEffect, useState } from 'react'
import './index.css'
import ToDo from './component/ToDo'
import axios from "axios";
import { baseURl } from './utils/constant';


const App = () => {

const [toDos, setToDos] = useState([]);
const [input, setInput] = useState("");
const [updateUI, setUpdateUI] = useState(false);



useEffect(()=>{

  axios.get(`${baseURl}/get`)
  .then((res)=> setToDos(res.data))
  .catch((err)=>console.log(err))

},[updateUI])

const saveToDo =() =>{
    axios.post(`${baseURl}/save`, {toDo:input})
    .then(res=>{
      console.log(res.data);
      setUpdateUI((prevstate)=> !prevstate)
      setInput("")
     

    })
    .catch((err)=>console.log(err));
}






  return (
    <main>
       <div className='title'>
          <h1>TODO LIST</h1>

     <div className='inputtag'>
      <input value={input} onChange={(e)=>setInput(e.target.value)} type="text" placeholder='add text' />
      <button onClick={saveToDo}>add</button>
      </div>  
       <div>
         {toDos.map(el => <ToDo key={el._id} text={el.toDo} id={el._id} setUpdateUI={setUpdateUI}/>)}
         
       </div>
   </div>
    </main>
  
  )
}

export default App