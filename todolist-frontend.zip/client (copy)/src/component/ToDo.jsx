import React from 'react'
import { MdEdit } from "react-icons/md";
import { MdDelete } from "react-icons/md";
import { baseURl } from '../utils/constant';
import axios from 'axios';


const ToDo = ({text,id, setUpdateUI}) => {

const deleteTodo =()=>{
    axios.delete(`${baseURl}/delete/${id}`)
    .then(res =>{
        console.log(res.data);
        setUpdateUI((prevState)=> !prevState)
    })
}






  return (
    <div className='todo'>
       {text} 
      <MdEdit className='icon'/>
      <MdDelete className='icon2' onClick={deleteTodo}/>
    </div>
  )
}

export default ToDo