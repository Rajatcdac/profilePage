import React from 'react'

const Popup = () => {
  return (
    <div>Popup</div>
  )
}

export default Popup