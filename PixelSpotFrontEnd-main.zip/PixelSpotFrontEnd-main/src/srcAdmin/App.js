
import './App.css';
import MainRender from './MainRender';

function App() {
  return (
    <div className="App">
      <MainRender/>
    </div>
  );
}

export default App;
